package com.neeraj.UserNotesSpringBootApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserNotesSpringBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
